export default {
  // 首页轮播图
  homecasual: [],
  // 分类数组
  categoryList: [],
  // 首页的商品列表
  homeshoplist: [],
  // 推荐的商品列表
  recommendshoplist: [],
  // 商品详细信息
  goodsDetail: [],
  // 商品评论
  goodsComment: [],
  // 用户数据
  userInfo: {},
  // 购物车数据
  cartgoods: [],
  // 搜索结果
  searchresults: []
}
