// 入口文件

require('babel-register');
require('./src/app');